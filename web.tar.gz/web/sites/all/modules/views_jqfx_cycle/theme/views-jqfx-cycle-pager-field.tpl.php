<div<?php print $attributes; ?>>
  <?php print $rendered_field_items; ?>
</div>
