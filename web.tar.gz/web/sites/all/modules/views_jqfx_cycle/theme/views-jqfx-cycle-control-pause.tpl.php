<?php print $rendered_pause_link; ?>
