Overview

This module allows to "buy" nodes for Userpoints.

Installation

Requirements: Fields, Userpoints, Views

1) Upload to the sites/all/modules dir. Enable it on Modules page
2) Edit any content type that you want to use as Gift (you may use Gift content type. it supplied with module). 
   Module adds Node Gift tab on content type edit screen.
3) Save content type.
4) Add a few Gift nodes with prices.
5) Add few userpoints to any user and try to buy "Gifts"
6) Module adds Gifts tab to user account page.

